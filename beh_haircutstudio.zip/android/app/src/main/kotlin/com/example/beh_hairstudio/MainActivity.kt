package com.example.beh_hairstudio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
